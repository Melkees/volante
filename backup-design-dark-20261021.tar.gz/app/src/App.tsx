import { Routes, Route } from 'react-router'
import Navbar from '@/components/Navbar'
import CommandSearch from '@/components/CommandSearch'
import CookieBar from '@/components/CookieBar'
import Footer from '@/components/Footer'
import Home from '@/pages/Home'

export default function App() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Navbar />
      <CommandSearch />
      <Routes>
        <Route path="*" element={<Home />} />
      </Routes>
      <Footer />
      <CookieBar />
    </div>
  )
}
