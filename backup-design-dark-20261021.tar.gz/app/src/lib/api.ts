// Cliente tipado da API Volante — TODO dado dinâmico vem daqui (nunca hardcode).

export interface StatRow {
  key: string;
  label: string;
  value: string;
  hint?: string | null;
}

export interface Category {
  id: number;
  slug: string;
  name: string;
  icon: string;
  examples: string;
  image: string;
}

export interface RankingEntry {
  id?: number;
  board: string;
  position: number;
  name: string;
  value: number;
  href?: string | null;
}

export interface Rankings {
  marcas: RankingEntry[];
  eletrificados: { hibridos: RankingEntry[]; eletricos: RankingEntry[]; total: number };
  veiculos: RankingEntry[];
}

export interface PaybackParams {
  km_mes: number;
  gasolina: number;
  energia: number;
  economia_5_anos_valor: number;
  carros: { nome: string; tipo: 'gasolina' | 'hibrido' | 'eletrico'; consumo: number }[];
}

export interface PaybackHighlight {
  badge: string;
  economia_5_anos: string;
  comparacao: string;
  preco_combustiveis: { gasolina: string; energia: string };
  custos_mensais: { veiculo: string; detalhe: string | null; valor: string }[];
  equilibrio: { texto: string; meses: number }[];
  chips: string[];
  params: PaybackParams;
}

export interface RecomendacaoHighlight {
  card: string;
  veiculo: string;
  preco: string;
  pergunta: string;
  pontos_fortes: string[];
  atencao: string[];
  rodape: string;
  preco_valor: number;
}

export interface FinanciamentoParams {
  valor_padrao: number;
  entrada_pct: number;
  cdc: { meses: number; taxa_mes: number };
  leasing: { meses: number; taxa_mes: number };
  consorcio: { meses: number; taxa_mes: number };
  assinatura: { mensalidade: number };
}

export interface FinanciamentoHighlight {
  exemplo: string;
  veiculo_financiado: string;
  opcoes: { modalidade: string; parcela: string; total: string }[];
  selo: string;
  params: FinanciamentoParams;
}

export interface Highlights {
  payback: PaybackHighlight;
  recomendacao: RecomendacaoHighlight;
  financiamento: FinanciamentoHighlight;
}

export interface Tool {
  id: number;
  title: string;
  description: string;
  action_label: string;
  href: string;
  icon: string;
  badge: string | null;
}

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`GET ${path} → ${res.status}`);
  return res.json() as Promise<T>;
}

export const api = {
  stats: () => get<{ hero: StatRow[]; rankings: StatRow[] }>('/api/stats'),
  categories: () => get<Category[]>('/api/categories'),
  rankings: () => get<Rankings>('/api/rankings'),
  highlights: () => get<Highlights>('/api/highlights'),
  tools: () => get<Tool[]>('/api/tools'),
};

export const brl = (n: number) =>
  n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });

export const brl2 = (n: number) =>
  n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 });
