// Navbar flutuante glass do Volante — sticky, pill centralizada, dropdown Parceiros.
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ChevronDown, Menu, Search, X } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Brand } from '@/components/Brand';
import { cn } from '@/lib/utils';

const LINKS = [
  { label: 'Buscar', href: '/busca' },
  { label: 'Comparar', href: '/comparar' },
  { label: 'Decida com IA', href: '/decida' },
  { label: 'Financiamento', href: '/financiamento' },
  { label: 'Calculadora', href: '/calculadora' },
  { label: 'Rankings', href: '/rankings' },
];

const PARCEIROS = [
  { label: 'Concessionárias', href: '/parceiros/concessionarias' },
  { label: 'Seguros', href: '/parceiros/seguros' },
  { label: 'Vistorias', href: '/parceiros/vistorias' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-3 z-50 px-3 md:top-4">
      <nav className="glass mx-auto flex h-14 w-full max-w-7xl items-center justify-between gap-3 rounded-2xl border border-white/[0.07] px-4 shadow-[0_8px_32px_rgba(0,0,0,0.45)] md:px-5">
        <Link to="/" aria-label="Volante — página inicial" className="shrink-0">
          <Brand />
        </Link>

        {/* Links desktop */}
        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <Link
                to={l.href}
                className="rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors duration-200 hover:bg-white/5 hover:text-foreground"
              >
                {l.label}
              </Link>
            </li>
          ))}
          <li>
            <DropdownMenu>
              <DropdownMenuTrigger
                className={cn(
                  'inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm outline-none transition-colors duration-200',
                  'text-muted-foreground hover:bg-white/5 hover:text-foreground focus-visible:text-foreground data-[state=open]:bg-white/5 data-[state=open]:text-foreground',
                )}
              >
                Parceiros
                <ChevronDown className="h-3.5 w-3.5 transition-transform duration-200 group-data-[state=open]:rotate-180" />
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="start"
                sideOffset={12}
                className="rounded-xl border-white/[0.12] bg-popover p-1.5 shadow-[0_16px_48px_rgba(0,0,0,0.6)]"
              >
                {PARCEIROS.map((p) => (
                  <DropdownMenuItem key={p.href} asChild>
                    <Link
                      to={p.href}
                      className="cursor-pointer rounded-lg px-3 py-2 text-sm text-muted-foreground outline-none focus:bg-white/5 focus:text-foreground"
                    >
                      {p.label}
                    </Link>
                  </DropdownMenuItem>
                ))}
                <div className="mx-2 my-1 h-px bg-white/[0.08]" />
                <DropdownMenuItem asChild>
                  <Link
                    to="/parceiros"
                    className="cursor-pointer rounded-lg px-3 py-2 text-sm font-medium text-primary outline-none focus:bg-primary/10"
                  >
                    Seja um Parceiro
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </li>
        </ul>

        {/* Ações */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            aria-label="Abrir busca global"
            onClick={() => window.dispatchEvent(new CustomEvent('volante:open-search'))}
            className="hidden h-9 items-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.04] px-2.5 text-muted-foreground transition-colors duration-200 hover:border-primary/30 hover:text-foreground sm:inline-flex"
          >
            <Search className="h-4 w-4" />
            <kbd className="rounded-md border border-white/10 bg-white/5 px-1.5 py-0.5 font-display text-[0.65rem] text-muted-foreground">
              /
            </kbd>
          </button>

          <Button asChild variant="ghost" className="hidden rounded-xl text-sm text-muted-foreground hover:text-foreground md:inline-flex">
            <Link to="/users/sign_in">Entrar</Link>
          </Button>
          <Button asChild className="hidden rounded-xl bg-primary font-semibold text-primary-foreground shadow-[0_0_0_0_rgba(240,180,41,0)] transition-shadow duration-200 hover:bg-primary/90 hover:shadow-[0_0_24px_rgba(240,180,41,0.25)] md:inline-flex">
            <Link to="/users/sign_up">Criar conta</Link>
          </Button>

          {/* Hamburguer mobile */}
          <button
            type="button"
            aria-label={open ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.04] text-foreground transition-colors duration-200 hover:border-primary/30 lg:hidden"
          >
            {open ? <X className="h-4.5 w-4.5" /> : <Menu className="h-4.5 w-4.5" />}
          </button>
        </div>
      </nav>

      {/* Scrim mobile — escurece o resto da página; clique fora fecha */}
      {open && (
        <button
          type="button"
          aria-label="Fechar menu"
          onClick={() => setOpen(false)}
          className="fixed inset-0 -z-10 bg-black/60 lg:hidden"
        />
      )}

      {/* Painel mobile — quase opaco para o hero não sangrar atrás dos links */}
      {open && (
        <div className="mx-auto mt-2 w-full rounded-2xl border border-white/[0.07] bg-[#0C1119]/97 p-3 shadow-[0_20px_60px_rgba(0,0,0,0.75)] backdrop-blur-xl lg:hidden">
          {/* Busca no topo do painel */}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              window.dispatchEvent(new CustomEvent('volante:open-search'));
            }}
            className="mb-2 flex h-12 w-full items-center gap-3 rounded-xl border border-white/[0.1] bg-white/[0.04] px-4 text-sm text-muted-foreground transition-colors duration-200 hover:border-primary/30 hover:text-foreground"
          >
            <Search className="h-4.5 w-4.5 shrink-0" />
            <span className="flex-1 text-left">Buscar no Volante</span>
            <kbd className="rounded-md border border-white/10 bg-white/5 px-1.5 py-0.5 font-display text-[0.65rem] text-muted-foreground">
              /
            </kbd>
          </button>
          <ul className="flex flex-col">
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link
                  to={l.href}
                  onClick={() => setOpen(false)}
                  className="flex min-h-[44px] items-center rounded-lg px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            <li className="px-3 pb-1 pt-3 text-[0.65rem] font-semibold tracking-[0.2em] text-muted-foreground/70">
              PARCEIROS
            </li>
            {PARCEIROS.map((p) => (
              <li key={p.href}>
                <Link
                  to={p.href}
                  onClick={() => setOpen(false)}
                  className="flex min-h-[44px] items-center rounded-lg px-5 py-3 text-sm text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
                >
                  {p.label}
                </Link>
              </li>
            ))}
            <li>
              <Link
                to="/parceiros"
                onClick={() => setOpen(false)}
                className="flex min-h-[44px] items-center rounded-lg px-5 py-3 text-sm font-medium text-primary transition-colors hover:bg-primary/10"
              >
                Seja um Parceiro
              </Link>
            </li>
          </ul>
          <div className="mt-3 flex gap-2 border-t border-white/[0.08] pt-3">
            <Button asChild variant="outline" className="flex-1 rounded-xl border-white/10 bg-transparent text-sm hover:bg-white/5">
              <Link to="/users/sign_in" onClick={() => setOpen(false)}>Entrar</Link>
            </Button>
            <Button asChild className="flex-1 rounded-xl bg-primary font-semibold text-primary-foreground hover:bg-primary/90">
              <Link to="/users/sign_up" onClick={() => setOpen(false)}>Criar conta</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
