import { Instagram, Music2, Twitter, Mail, MessageSquarePlus } from 'lucide-react';
import { Brand } from '@/components/Brand';

const FERRAMENTAS = [
  { label: 'Buscar Veículos', href: '/veiculos' },
  { label: 'Comparar', href: '/comparar' },
  { label: 'Decida Meu Carro', href: '/recomendacoes/new' },
  { label: 'Calculadora de Custos', href: '/calculadora' },
  { label: 'Financiamento', href: '/financiamento' },
  { label: 'Rankings de Vendas', href: '/rankings' },
  { label: 'Blog', href: '/blog' },
];

const PARCEIROS = [
  { label: 'Concessionárias', href: '/parceiros/concessionarias' },
  { label: 'Seguros', href: '/parceiros/seguros' },
  { label: 'Vistorias', href: '/parceiros/vistorias' },
  { label: 'Seja um Parceiro', href: '/parceiros', accent: true },
];

const CONTA = [
  { label: 'Entrar', href: '/users/sign_in' },
  { label: 'Criar Conta', href: '/users/sign_up' },
];

function Column({ title, links }: { title: string; links: { label: string; href: string; accent?: boolean }[] }) {
  return (
    <div>
      <h3 className="mb-4 font-display text-sm font-semibold tracking-wide text-foreground">{title}</h3>
      <ul className="space-y-2.5">
        {links.map((l) => (
          <li key={l.label}>
            <a
              href={l.href}
              className={
                l.accent
                  ? 'inline-block py-2 text-sm font-medium text-primary transition-colors hover:text-primary/80'
                  : 'inline-block py-2 text-sm text-muted-foreground transition-colors hover:text-foreground'
              }
            >
              {l.label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Footer() {
  return (
    <footer className="border-t border-white/[0.08] bg-background">
      <div className="mx-auto w-full max-w-7xl px-4 py-14 md:px-8">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Brand size="lg" tagline />
            <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground">
              Plataforma automotiva gratuita: compare modelos, simule custos e descubra o carro
              certo com IA. Dados oficiais FIPE e FENABRAVE.
            </p>
            <div className="mt-6 flex items-center gap-3">
              {[
                { icon: Instagram, href: 'https://instagram.com/volante', label: 'Instagram' },
                { icon: Music2, href: 'https://www.tiktok.com/@volante', label: 'TikTok' },
                { icon: Twitter, href: 'https://x.com/volante', label: 'X' },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/[0.08] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
              <a
                href="mailto:suporte@volante.com.br"
                className="ml-2 flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-primary"
              >
                <Mail className="h-4 w-4" /> suporte@volante.com.br
              </a>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7">
            <Column title="Ferramentas" links={FERRAMENTAS} />
            <Column title="Parceiros" links={PARCEIROS} />
            <Column title="Sua Conta" links={CONTA} />
          </div>
        </div>

        <div className="card-hover mt-12 flex flex-col items-center justify-between gap-4 rounded-2xl border border-white/[0.07] glass px-6 py-5 sm:flex-row">
          <div className="flex items-center gap-3">
            <MessageSquarePlus className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground">Tem alguma sugestão ou problema?</p>
              <p className="text-xs text-muted-foreground">Seu feedback nos ajuda a melhorar a plataforma</p>
            </div>
          </div>
          <button
            type="button"
            className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-background transition-colors hover:bg-primary/90"
          >
            Enviar feedback
          </button>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/[0.08] pt-6 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            © 2026 Volante · Dados oficiais: <strong className="font-semibold text-foreground/80">Tabela FIPE</strong> ·{' '}
            Rankings: <strong className="font-semibold text-foreground/80">FENABRAVE</strong>
          </p>
          <nav className="flex items-center gap-2 text-xs text-muted-foreground">
            <a href="/sobre" className="transition-colors hover:text-foreground">Sobre</a>
            <span>·</span>
            <a href="/privacidade" className="transition-colors hover:text-foreground">Privacidade</a>
            <span>·</span>
            <a href="/termos" className="transition-colors hover:text-foreground">Termos</a>
          </nav>
        </div>
      </div>
    </footer>
  );
}
