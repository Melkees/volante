import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Car,
  CarFront,
  CarTaxiFront,
  Truck,
  Search,
  Sparkles,
  Scale,
  Calculator,
  Banknote,
  Trophy,
  Newspaper,
  Wrench,
  Component,
  type LucideIcon,
} from 'lucide-react';
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from '@/components/ui/command';
import { api, type Category, type Tool, type RankingEntry } from '@/lib/api';

const ICONS: Record<string, LucideIcon> = {
  Car,
  CarFront,
  CarTaxiFront,
  Truck,
  Search,
  Sparkles,
  Scale,
  Calculator,
  Banknote,
  Trophy,
  Newspaper,
};

function toolIcon(name: string): LucideIcon {
  return ICONS[name] ?? Wrench;
}

export default function CommandSearch() {
  const [open, setOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [veiculos, setVeiculos] = useState<RankingEntry[]>([]);
  const loaded = useRef(false);

  const load = useCallback(() => {
    if (loaded.current) return;
    loaded.current = true;
    api.categories().then(setCategories).catch(() => {});
    api.tools().then(setTools).catch(() => {});
    api
      .rankings()
      .then((r) => setVeiculos(r.veiculos))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const openIt = () => {
      load();
      setOpen(true);
    };
    window.addEventListener('volante:open-search', openIt);
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);
      if (e.key === '/' && !typing) {
        e.preventDefault();
        openIt();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('volante:open-search', openIt);
      window.removeEventListener('keydown', onKey);
    };
  }, [load]);

  return (
    <CommandDialog
      open={open}
      onOpenChange={setOpen}
      title="Buscar no Volante"
      description="Categorias, ferramentas e veículos"
      className="border-white/[0.1] bg-popover/95 backdrop-blur-xl sm:max-w-xl"
    >
      <CommandInput placeholder="Buscar carros, ferramentas, categorias…" className="text-base sm:text-sm" />
      <CommandList className="min-h-72">
        <CommandEmpty>Nenhum resultado encontrado.</CommandEmpty>

        {categories.length > 0 && (
          <CommandGroup heading="Categorias">
            {categories.map((c) => (
              <CommandItem key={c.slug} value={c.name} onSelect={() => { setOpen(false); window.location.href = `/busca?category=${c.slug}`; }}>
                <Car className="text-primary" />
                <span>{c.name}</span>
                <span className="ml-auto text-xs text-muted-foreground">{c.examples}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {tools.length > 0 && (
          <CommandGroup heading="Ferramentas">
            {tools.map((t) => {
              const Icon = toolIcon(t.icon);
              return (
                <CommandItem key={t.id} value={`${t.title} ${t.description}`} onSelect={() => { setOpen(false); window.location.href = t.href; }}>
                  <Icon className="text-primary" />
                  <span>{t.title}</span>
                  <span className="ml-auto truncate pl-4 text-xs text-muted-foreground">{t.description}</span>
                </CommandItem>
              );
            })}
          </CommandGroup>
        )}

        {veiculos.length > 0 && (
          <CommandGroup heading="Veículos mais vendidos">
            {veiculos.map((v) => (
              <CommandItem key={v.name} value={v.name} onSelect={() => { setOpen(false); window.location.href = v.href || '/busca'; }}>
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10 font-display text-[0.65rem] font-bold text-primary">
                  {v.position}
                </span>
                <span>{v.name}</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {v.value.toLocaleString('pt-BR')} unid.
                </span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
      <div className="border-t border-white/[0.08] px-4 py-2.5 text-[0.7rem] text-muted-foreground">
        ↑↓ navegar · ↵ abrir · esc fechar
      </div>
    </CommandDialog>
  );
}
