import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Cookie } from 'lucide-react';

const KEY = 'volante:cookies';

export default function CookieBar() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      setShow(!localStorage.getItem(KEY));
    } catch {
      setShow(true);
    }
  }, []);

  const accept = () => {
    try {
      localStorage.setItem(KEY, '1');
    } catch {
      /* noop */
    }
    setShow(false);
  };

  return (
    <>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="fixed inset-x-4 bottom-4 z-50 mx-auto flex max-w-2xl flex-col items-center gap-4 rounded-xl border border-white/[0.1] glass px-5 py-4 shadow-[0_12px_40px_-12px_var(--glow)] sm:flex-row"
          role="dialog"
          aria-label="Aviso de cookies"
        >
          <Cookie className="h-5 w-5 shrink-0 text-primary" />
          <p className="flex-1 text-center text-sm text-muted-foreground sm:text-left">
            Usamos cookies para manter você conectado e melhorar a plataforma.{' '}
            <a href="/privacidade" className="font-medium text-primary transition-colors hover:text-primary/80">
              Saiba mais
            </a>
          </p>
          <button
            type="button"
            onClick={accept}
            className="shrink-0 rounded-xl bg-primary px-5 py-2 text-sm font-semibold text-background transition-colors hover:bg-primary/90"
          >
            Entendi
          </button>
        </motion.div>
      )}
    </>
  );
}
