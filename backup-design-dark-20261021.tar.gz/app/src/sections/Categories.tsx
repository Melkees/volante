// "Explorar por Categoria" — cards fotográficos com overlay, ícones lucide, dados da API.
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowRight, Car, CarFront, CarTaxiFront, Truck } from 'lucide-react';
import { api, type Category } from '@/lib/api';
import { Section, SectionHeading, Reveal } from '@/lib/ui';
import { cn } from '@/lib/utils';

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Car,
  CarFront,
  CarTaxiFront,
  Truck,
};

function CategoryCard({ cat, delay }: { cat: Category; delay: number }) {
  const Icon = ICONS[cat.icon] ?? Car;
  return (
    <Reveal delay={delay}>
      <Link
        to={`/busca?category=${cat.slug}`}
        className="card-hover group relative block overflow-hidden rounded-2xl border border-white/[0.07] transition-colors duration-200 hover:border-primary/35"
      >
        <img
          src={cat.image}
          alt={cat.name}
          loading="lazy"
          decoding="async"
          width={600}
          height={400}
          className="absolute inset-0 h-56 w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
        {/* Overlay gradiente na base */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/5"
        />
        {/* Chip "Ver todos →" topo-direita */}
        <span className="glass absolute right-3 top-3 inline-flex items-center gap-1 rounded-full border border-white/10 px-3 py-1 text-xs font-medium text-foreground opacity-0 transition-opacity duration-200 group-hover:opacity-100 max-sm:opacity-100">
          Ver todos
          <ArrowRight className="h-3 w-3 transition-transform duration-200 group-hover:translate-x-0.5" />
        </span>
        {/* Conteúdo na base */}
        <div className="relative flex h-56 flex-col justify-end p-5">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.06] backdrop-blur-sm">
              <Icon className="h-5 w-5 text-primary" />
            </span>
            <div className="min-w-0">
              <h3 className="truncate font-display text-lg font-bold text-white">{cat.name}</h3>
              <p className="truncate text-xs text-white/60">{cat.examples}</p>
            </div>
          </div>
        </div>
      </Link>
    </Reveal>
  );
}

export default function Categories() {
  const [cats, setCats] = useState<Category[]>([]);

  useEffect(() => {
    let alive = true;
    api.categories().then((c) => alive && setCats(c)).catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  return (
    <Section id="categorias" className={cn('bg-[#0C1119]')}>
      <SectionHeading
        eyebrow="CATÁLOGO"
        title="Explorar por"
        highlight="Categoria"
        sub="Encontre o veículo certo para o seu estilo de vida"
      />
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {cats.map((cat, i) => (
          <CategoryCard key={cat.id} cat={cat} delay={i * 0.08} />
        ))}
      </div>
    </Section>
  );
}
