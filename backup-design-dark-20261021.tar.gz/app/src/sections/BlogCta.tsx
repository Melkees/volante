import { Newspaper, ArrowRight } from 'lucide-react';
import { Section, Reveal } from '@/lib/ui';

export default function BlogCta() {
  return (
    <Section id="blog" className="bg-surface-2">
      <Reveal>
        <a
          href="/blog"
          className="glass card-hover group flex flex-col items-start gap-5 rounded-2xl border border-white/[0.07] p-6 sm:flex-row sm:items-center md:p-8"
        >
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Newspaper className="h-7 w-7" />
          </span>
          <span className="flex-1">
            <h3 className="font-display text-xl font-bold text-foreground md:text-2xl">Blog do Volante</h3>
            <p className="mt-1 text-sm text-muted-foreground md:text-base">
              Análises, comparativos e tendências do mercado automotivo
            </p>
          </span>
          <span className="flex items-center gap-1.5 font-display text-sm font-semibold text-primary transition-transform group-hover:translate-x-1">
            Acessar o blog <ArrowRight className="h-4 w-4" />
          </span>
        </a>
      </Reveal>
    </Section>
  );
}
