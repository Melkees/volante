// [S7] Seção IA: 4 passos em timeline + card "Recomendação #1".
import { useEffect, useState } from 'react';
import { Check, AlertTriangle, ArrowRight, Sparkles } from 'lucide-react';
import { Section, SectionHeading, Reveal } from '@/lib/ui';
import { api, brl, type Highlights } from '@/lib/api';

const PASSOS = [
  {
    titulo: 'Perfil em 10 perguntas',
    desc: 'Orçamento, uso, perfil familiar, km por mês, combustível, câmbio e suas prioridades',
  },
  {
    titulo: 'IA analisa o catálogo com preços FIPE',
    desc: 'Especificações técnicas reais, consumo INMETRO e preço atualizado do mês',
  },
  {
    titulo: 'Opções rankeadas com análise honesta',
    desc: 'Por que cada um serve para você, pontos fortes, fracos e comparativo entre eles',
  },
  {
    titulo: 'Ficha técnica completa + comparativo direto',
    desc: 'Link direto para cada veículo e opção de comparar lado a lado as opções recomendadas',
  },
];

export default function AiReco() {
  const [h, setH] = useState<Highlights | null>(null);

  useEffect(() => {
    api.highlights().then(setH);
  }, []);

  const r = h?.recomendacao;

  return (
    <Section id="ia" className="bg-surface-2">
      <div className="grid gap-10 lg:grid-cols-2 lg:gap-14">
        {/* Passos */}
        <div>
          <SectionHeading
            align="left"
            eyebrow="INTELIGÊNCIA ARTIFICIAL"
            title="Não sabe qual carro comprar?"
            highlight="Deixa a IA decidir."
            sub="Responda 10 perguntas sobre seu perfil: orçamento, uso diário, família, combustível e prioridades. Nossa IA cruza tudo isso com preços FIPE reais e entrega opções rankeadas com análise honesta."
          />

          <div className="relative space-y-8 pl-2">
            {PASSOS.map((p, i) => (
              <Reveal key={p.titulo} delay={i * 0.08}>
                <div className="relative flex gap-4">
                  {i < PASSOS.length - 1 && (
                    <span className="absolute left-[19px] top-11 h-[calc(100%-24px)] w-px bg-white/10" />
                  )}
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-primary/40 font-display text-sm font-semibold text-primary">
                    {i + 1}
                  </span>
                  <div>
                    <p className="font-semibold">{p.titulo}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.2}>
            <a
              href="/decida"
              className="mt-10 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-display font-semibold text-primary-foreground transition-colors duration-200 hover:bg-primary/90"
            >
              Gerar minha recomendação
              <ArrowRight className="h-4 w-4" />
            </a>
          </Reveal>
        </div>

        {/* Card destaque */}
        <Reveal delay={0.1} className="lg:pt-24">
          <div className="rounded-2xl border border-primary/20 bg-card p-6 shadow-[0_20px_60px_-30px_var(--glow)] md:p-8">
            <div className="mb-6 flex items-center justify-between">
              <span className="inline-flex items-center gap-2 text-xs font-medium tracking-widest text-muted-foreground">
                <Sparkles className="h-4 w-4 text-primary" />
                RECOMENDAÇÃO #1
              </span>
              <span className="rounded-full border border-primary/25 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                No catálogo
              </span>
            </div>

            <h3 className="font-display text-xl font-bold">{r?.veiculo ?? '—'}</h3>
            <p className="mt-2 flex items-center gap-2">
              <span className="font-display text-2xl font-bold text-primary">
                {r ? brl(r.preco_valor) : '—'}
              </span>
              <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-xs text-muted-foreground">
                FIPE
              </span>
            </p>

            <div className="mt-7 rounded-xl border border-white/8 bg-white/[0.03] p-5">
              <p className="font-display font-semibold">{r?.pergunta ?? 'Por que este veículo?'}</p>
              <div className="mt-4 grid gap-6 sm:grid-cols-2">
                <div>
                  <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground">
                    PONTOS FORTES
                  </p>
                  <ul className="space-y-1.5">
                    {(r?.pontos_fortes ?? []).map((p) => (
                      <li key={p} className="flex items-start gap-2 text-sm">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground">
                    ATENÇÃO
                  </p>
                  <ul className="space-y-1.5">
                    {(r?.atencao ?? []).map((a) => (
                      <li key={a} className="flex items-start gap-2 text-sm">
                        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                        {a}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <p className="mt-6 text-sm text-muted-foreground">{r?.rodape ?? '+ 4 outras opções rankeadas pela IA'}</p>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
