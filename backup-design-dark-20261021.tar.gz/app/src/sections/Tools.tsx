// [S6] Grid de ferramentas — cards glass com ícone, badge e ação.
import { useEffect, useState } from 'react';
import {
  Search,
  Sparkles,
  Scale,
  Calculator,
  Banknote,
  Trophy,
  ArrowRight,
  type LucideIcon,
} from 'lucide-react';
import { Section, SectionHeading, Reveal } from '@/lib/ui';
import { api, type Tool } from '@/lib/api';

const ICONS: Record<string, LucideIcon> = {
  Search,
  Sparkles,
  Scale,
  Calculator,
  Banknote,
  Trophy,
};

export default function Tools() {
  const [tools, setTools] = useState<Tool[]>([]);

  useEffect(() => {
    api.tools().then(setTools);
  }, []);

  return (
    <Section id="ferramentas">
      <SectionHeading
        eyebrow="FERRAMENTAS"
        title="Tudo o que você precisa"
        highlight="para decidir"
        sub="Acesso rápido a todas as ferramentas do Volante."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((tool, i) => {
          const Icon = ICONS[tool.icon] ?? Sparkles;
          return (
            <Reveal key={tool.id} delay={i * 0.06}>
              <a
                href={tool.href}
                className="glass card-hover block h-full rounded-2xl border p-6"
              >
                <div className="mb-5 flex items-start justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                  {tool.badge && (
                    <span className="rounded-full border border-primary/25 bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                      {tool.badge}
                    </span>
                  )}
                </div>
                <h3 className="font-display text-lg font-semibold">{tool.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{tool.description}</p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                  {tool.action_label}
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </span>
              </a>
            </Reveal>
          );
        })}
      </div>
    </Section>
  );
}
