// [S5] Calculadora de payback elétrico — sliders + resultados AO VIVO.
import { useEffect, useState } from 'react';
import { Zap } from 'lucide-react';
import { Section, SectionHeading, Reveal } from '@/lib/ui';
import { api, brl2, type PaybackHighlight } from '@/lib/api';
import { Slider } from '@/components/ui/slider';

interface Params {
  km_mes: number;
  gasolina: number;
  energia: number;
  carros: PaybackHighlight['params']['carros'];
}

function custoMensal(p: Params, carro: Params['carros'][number]) {
  const litros = p.km_mes / carro.consumo;
  const preco = carro.tipo === 'eletrico' ? p.energia : p.gasolina;
  return litros * preco;
}

export default function Payback() {
  const [data, setData] = useState<PaybackHighlight | null>(null);
  const [params, setParams] = useState<Params | null>(null);

  useEffect(() => {
    api.highlights().then((h) => {
      setData(h.payback);
      setParams({ ...h.payback.params });
    });
  }, []);

  const maxCusto =
    params ? Math.max(...params.carros.map((c) => custoMensal(params, c))) : 0;
  const polo =
    params?.carros.find((c) => c.tipo === 'gasolina') ?? params?.carros[0];
  const ev = params?.carros.find((c) => c.tipo === 'eletrico');
  const economiaMes =
    params && polo && ev ? custoMensal(params, polo) - custoMensal(params, ev) : 0;

  return (
    <Section id="payback" className="bg-surface-2">
      <SectionHeading
        eyebrow="CALCULADORA"
        title="Elétrico"
        highlight="compensa pra você?"
        sub="Descubra em 30 segundos se a troca vale a pena, considerando quanto você roda, o preço do combustível e a energia elétrica na sua região."
      />

      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        {/* Controles */}
        <Reveal>
          <div className="glass h-full rounded-2xl border p-6 md:p-8">
            <div className="mb-6 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Zap className="h-5 w-5" />
              </span>
              <div>
                <p className="font-display font-semibold">Suas condições</p>
                <p className="text-sm text-muted-foreground">Arraste e veja ao vivo</p>
              </div>
            </div>

            {params && (
              <div className="space-y-7">
                {(
                  [
                    { label: 'Km por mês', min: 500, max: 5000, step: 100, key: 'km_mes', fmt: (v: number) => `${v} km` },
                    { label: 'Gasolina', min: 4, max: 8, step: 0.05, key: 'gasolina', fmt: (v: number) => `R$ ${v.toFixed(2)}/L` },
                    { label: 'Energia', min: 0.5, max: 1.5, step: 0.01, key: 'energia', fmt: (v: number) => `R$ ${v.toFixed(2)}/kWh` },
                  ] as const
                ).map((s) => (
                  <div key={s.key}>
                    <div className="mb-3 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                      <span className="text-sm text-muted-foreground">{s.label}</span>
                      <span className="font-display text-lg font-semibold text-primary">
                        {s.fmt(params[s.key])}
                      </span>
                    </div>
                    <Slider
                      className="py-2 [&_[data-slot=slider-thumb]]:size-7 md:[&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-primary [&_[data-slot=slider-thumb]]:bg-primary"
                      min={s.min}
                      max={s.max}
                      step={s.step}
                      value={[params[s.key]]}
                      onValueChange={([v]) => setParams((p) => (p ? { ...p, [s.key]: v } : p))}
                    />
                  </div>
                ))}
              </div>
            )}

            {data && (
              <div className="mt-8 mb-2 flex flex-wrap gap-2.5">
                {data.chips.map((chip) => (
                  <span
                    key={chip}
                    className="rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-muted-foreground"
                  >
                    {chip}
                  </span>
                ))}
              </div>
            )}
          </div>
        </Reveal>

        {/* Resultados */}
        <Reveal delay={0.1}>
          <div className="rounded-2xl border bg-card p-6 md:p-8">
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
              <p className="font-display font-semibold">Custo mensal de combustível</p>
              <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-muted-foreground">
                {data?.badge ?? 'Exemplo ilustrativo'}
              </span>
            </div>

            {params && (
              <div className="space-y-5">
                {params.carros.map((c) => {
                  const custo = custoMensal(params, c);
                  const pct = maxCusto > 0 ? (custo / maxCusto) * 100 : 0;
                  return (
                    <div key={c.nome}>
                      <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                        <span className="text-sm font-medium">
                          {c.nome}
                          <span className="ml-2 text-xs text-muted-foreground">
                            {c.tipo === 'eletrico' ? 'elétrico' : c.tipo === 'hibrido' ? 'híbrido' : 'gasolina'}
                          </span>
                        </span>
                        <span className="font-display font-semibold">{brl2(custo)}/mês</span>
                      </div>
                      <div className="h-3.5 overflow-hidden rounded-full bg-white/5 md:h-3">
                        <div
                          className={`h-full rounded-full transition-[width] duration-500 ease-out ${
                            c.tipo === 'eletrico' ? 'bg-primary' : 'bg-white/25'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {polo && ev && (
              <div className="mt-8 grid gap-4 border-t border-white/8 pt-6 sm:grid-cols-2">
                <div>
                  <p className="text-sm text-muted-foreground">Economia vs gasolina em 12 meses</p>
                  <p className="font-display text-xl font-bold text-primary">{brl2(economiaMes * 12)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">em 60 meses</p>
                  <p className="font-display text-xl font-bold text-primary">{brl2(economiaMes * 60)}</p>
                </div>
              </div>
            )}

            {data && (
              <p className="mt-6 text-xs text-muted-foreground">
                Referência do exemplo oficial: economia de 5 anos de{' '}
                <span className="text-foreground">{data.economia_5_anos}</span>
                {data.equilibrio.map((e) => (
                  <span key={e.texto}>
                    {' '}
                    · {e.texto} <span className="text-primary">{e.meses} meses</span>
                  </span>
                ))}
              </p>
            )}
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
