// Hero full-bleed do Volante — foto real + overlay premium + stats com count-up (dados da API).
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowRight, Sparkles } from 'lucide-react';
import { api, type StatRow } from '@/lib/api';
import { useCountUp, Reveal } from '@/lib/ui';
import { Button } from '@/components/ui/button';

/** "4.860+" → { n: 4860, suffix: "+" } · "97%" → { n: 97, suffix: "%" } */
function parseStat(value: string) {
  const m = value.match(/^([\d.,]+)\s*(\+|%)?/);
  const n = m ? Number(m[1].replace(/\./g, '').replace(',', '.')) : 0;
  return { n: Number.isFinite(n) ? n : 0, suffix: m?.[2] ?? '' };
}

function formatN(n: number) {
  return Math.round(n).toLocaleString('pt-BR');
}

function StatItem({ stat, delay }: { stat: StatRow; delay: number }) {
  const { n, suffix } = parseStat(stat.value);
  const { ref, value } = useCountUp(n);
  return (
    <Reveal delay={delay} className="px-6 text-center first:pl-0 last:pr-0 md:px-10">
      <p className="font-display text-3xl font-bold text-foreground md:text-4xl">
        <span ref={ref}>{formatN(value)}</span>
        <span className="text-primary">{suffix}</span>
      </p>
      <p className="mt-1.5 text-xs font-medium tracking-wide text-muted-foreground md:text-sm">
        {stat.label}
      </p>
    </Reveal>
  );
}

export default function Hero() {
  const [heroStats, setHeroStats] = useState<StatRow[]>([]);

  useEffect(() => {
    let alive = true;
    api.stats().then((s) => alive && setHeroStats(s.hero)).catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  return (
    <section className="relative flex min-h-[92vh] items-center justify-center overflow-hidden">
      {/* Foto real + overlays */}
      <img
        src="/assets/hero-home.webp"
        alt=""
        aria-hidden="true"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(to top, #0A0E14 0%, rgba(10,14,20,0.7) 55%, transparent 100%)',
        }}
      />
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 70% 55% at 50% 42%, rgba(10,14,20,0.25) 0%, rgba(10,14,20,0.78) 100%)',
        }}
      />

      {/* Conteúdo */}
      <div className="relative z-10 mx-auto w-full max-w-5xl px-4 pb-12 pt-28 text-center md:px-8 md:pt-32">
        <Reveal>
          <span className="glass inline-flex items-center gap-2.5 rounded-full border border-white/15 px-4 py-1.5 text-xs font-medium tracking-wide text-foreground/90">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            FIPE · FENABRAVE · IA · atualizado mensalmente
          </span>
        </Reveal>

        <Reveal delay={0.1}>
          <h1 className="mx-auto mt-6 max-w-4xl font-display text-4xl font-bold leading-[1.06] tracking-tight text-foreground sm:text-5xl md:text-6xl xl:text-7xl">
            A decisão do seu próximo carro,
            <br />
            <span className="text-primary">com clareza total.</span>
          </h1>
        </Reveal>

        <Reveal delay={0.2}>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
            Compare modelos, consulte preços FIPE e fichas técnicas, simule financiamento e deixe a
            IA apontar o carro certo para o seu perfil.
          </p>
        </Reveal>

        <Reveal delay={0.3} className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button
            asChild
            size="lg"
            className="h-12 rounded-xl bg-primary px-7 font-display text-base font-semibold text-primary-foreground shadow-[0_4px_28px_rgba(240,180,41,0.28)] transition-all duration-200 hover:bg-primary/90 hover:shadow-[0_4px_36px_rgba(240,180,41,0.4)]"
          >
            <Link to="/busca">
              Explorar o catálogo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="ghost"
            className="glass h-12 rounded-xl border-white/10 px-7 font-display text-base font-medium text-foreground transition-colors duration-200 hover:border-primary/30 hover:bg-white/[0.06]"
          >
            <Link to="/decida">
              <Sparkles className="mr-2 h-4 w-4 text-primary" />
              Decida com IA
            </Link>
          </Button>
        </Reveal>

        {/* Faixa de stats — dados reais da API */}
        {heroStats.length > 0 && (
          <Reveal delay={0.45} className="mt-10 md:mt-12">
            <div className="mx-auto flex w-fit flex-col items-stretch justify-center divide-y divide-white/[0.08] rounded-2xl border border-white/[0.07] bg-white/[0.03] py-5 backdrop-blur-sm sm:flex-row sm:divide-x sm:divide-y-0">
              {heroStats.slice(0, 3).map((s, i) => (
                <StatItem key={s.key} stat={s} delay={0.55 + i * 0.1} />
              ))}
            </div>
          </Reveal>
        )}
      </div>
    </section>
  );
}
