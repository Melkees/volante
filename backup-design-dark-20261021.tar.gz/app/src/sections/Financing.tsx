// [S8] Financiamento interativo — sliders + 4 modalidades calculadas AO VIVO.
import { useEffect, useMemo, useState } from 'react';
import { Car } from 'lucide-react';
import { Section, SectionHeading, Reveal } from '@/lib/ui';
import { api, brl, type FinanciamentoHighlight } from '@/lib/api';
import { Slider } from '@/components/ui/slider';

interface Modalidade {
  nome: string;
  parcela: number;
  meses: number;
  total: number;
  nota: string | null;
  fixa: boolean; // mensalidade fixa (assinatura)
}

/** PMT = PV·i / (1 − (1+i)⁻ⁿ) */
function pmt(pv: number, i: number, n: number) {
  return (pv * i) / (1 - Math.pow(1 + i, -n));
}

export default function Financing() {
  const [data, setData] = useState<FinanciamentoHighlight | null>(null);
  const [valor, setValor] = useState<number | null>(null);
  const [entrada, setEntrada] = useState<number | null>(null);

  useEffect(() => {
    api.highlights().then((h) => {
      setData(h.financiamento);
      setValor(h.financiamento.params.valor_padrao);
      setEntrada(h.financiamento.params.entrada_pct);
    });
  }, []);

  const pv = valor != null && entrada != null ? valor * (1 - entrada / 100) : 0;

  const modalidades = useMemo<Modalidade[]>(() => {
    const p = data?.params;
    if (!p) return [];
    const cdc = pmt(pv, p.cdc.taxa_mes, p.cdc.meses);
    const leasing = pmt(pv, p.leasing.taxa_mes, p.leasing.meses);
    const consorcio = pv / p.consorcio.meses;
    const assinatura = p.assinatura.mensalidade;
    return [
      { nome: 'CDC', parcela: cdc, meses: p.cdc.meses, total: cdc * p.cdc.meses, nota: null, fixa: false },
      { nome: 'Leasing', parcela: leasing, meses: p.leasing.meses, total: leasing * p.leasing.meses, nota: null, fixa: false },
      { nome: 'Consórcio', parcela: consorcio, meses: p.consorcio.meses, total: consorcio * p.consorcio.meses, nota: '0% de juros', fixa: false },
      { nome: 'Assinatura', parcela: assinatura, meses: 48, total: assinatura * 48, nota: 'Sem entrada', fixa: true },
    ];
  }, [data, pv]);

  const vencedor = modalidades.length
    ? modalidades.reduce((min, m) => (m.total < min.total ? m : min))
    : null;
  const maxTotal = modalidades.length ? Math.max(...modalidades.map((m) => m.total)) : 0;

  // Selo do payload ("Consórcio: menor custo total") adaptado ao vencedor real.
  const selo = vencedor ? `${vencedor.nome}: menor custo total` : null;

  return (
    <Section id="financiamento">
      <SectionHeading
        eyebrow="FINANCIAMENTO"
        title="Simule as"
        highlight="4 modalidades ao vivo"
        sub="CDC, Leasing, Consórcio e Assinatura comparados em tempo real, com destaque automático do menor custo total."
      />

      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        {/* Controles */}
        <Reveal>
          <div className="glass h-full rounded-2xl border p-6 md:p-8">
            <div className="mb-6 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Car className="h-5 w-5" />
              </span>
              <div>
                <p className="font-display font-semibold">Simulação</p>
                <p className="text-sm text-muted-foreground">Ajuste e compare ao vivo</p>
              </div>
            </div>

            {valor != null && entrada != null && (
              <div className="space-y-7">
                <div>
                  <div className="mb-3 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                    <span className="text-sm text-muted-foreground">Valor do carro</span>
                    <span className="font-display text-lg font-semibold text-primary">{brl(valor)}</span>
                  </div>
                  <Slider
                    className="py-2 [&_[data-slot=slider-thumb]]:size-7 md:[&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-primary [&_[data-slot=slider-thumb]]:bg-primary"
                    min={30000}
                    max={200000}
                    step={5000}
                    value={[valor]}
                    onValueChange={([v]) => setValor(v)}
                  />
                </div>
                <div>
                  <div className="mb-3 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                    <span className="text-sm text-muted-foreground">Entrada</span>
                    <span className="font-display text-lg font-semibold text-primary">{entrada}%</span>
                  </div>
                  <Slider
                    className="py-2 [&_[data-slot=slider-thumb]]:size-7 md:[&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-primary [&_[data-slot=slider-thumb]]:bg-primary"
                    min={0}
                    max={50}
                    step={5}
                    value={[entrada]}
                    onValueChange={([v]) => setEntrada(v)}
                  />
                </div>
              </div>
            )}

            <div className="mt-8 rounded-xl border border-white/8 bg-white/[0.03] p-4">
              <p className="text-sm text-muted-foreground">Veículo financiado</p>
              <p className="font-display text-xl font-bold">{brl(pv)}</p>
            </div>

            <p className="mt-6 mb-1 inline-block rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-muted-foreground">
              {data?.exemplo ?? 'Exemplo ilustrativo'}
            </p>
          </div>
        </Reveal>

        {/* Tabela ao vivo */}
        <Reveal delay={0.1}>
          <div className="rounded-2xl border bg-card p-6 md:p-8">
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
              <p className="font-display font-semibold">Comparativo de modalidades</p>
              {selo && (
                <span className="rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  {selo}
                </span>
              )}
            </div>

            <div className="space-y-5">
              {modalidades.map((m) => {
                const pct = maxTotal > 0 ? (m.total / maxTotal) * 100 : 0;
                const isVencedor = vencedor?.nome === m.nome;
                return (
                  <div
                    key={m.nome}
                    className={`rounded-xl border p-4 transition-colors duration-200 ${
                      isVencedor ? 'border-primary/40 bg-primary/5' : 'border-white/8 bg-white/[0.02]'
                    }`}
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="font-display font-semibold">
                        {m.nome}
                        {isVencedor && (
                          <span className="ml-2 rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                            menor custo total
                          </span>
                        )}
                      </span>
                      <span className="font-display font-semibold">
                        {m.fixa ? '' : `${m.meses}x `}
                        {brl(m.parcela)}
                        {m.fixa && <span className="text-sm text-muted-foreground">/mês</span>}
                      </span>
                    </div>
                    <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/5 md:h-2">
                      <div
                        className={`h-full rounded-full transition-[width] duration-500 ease-out ${
                          isVencedor ? 'bg-primary' : 'bg-white/25'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Total: {brl(m.total)}
                      {m.nota && <span> · {m.nota}</span>}
                    </p>
                  </div>
                );
              })}
            </div>

            <p className="mt-6 mb-1 inline-block rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-muted-foreground">
              Exemplo ilustrativo
            </p>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
